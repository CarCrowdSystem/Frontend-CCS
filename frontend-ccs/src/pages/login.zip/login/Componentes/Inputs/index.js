import React from 'react';

// import { Container } from './styles';

const Inputs = () => {
  return(
  <>
    <input className='input_email'/>
    <input className='input_senha'/>
  </>
  )
}

export default Inputs;