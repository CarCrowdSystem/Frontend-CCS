import { useState } from "react";
import "./Login.css";
import CampoTexto from "./Componentes/CampoTexto";
import Botao from "./Componentes/Botao";

/* function Login(props) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  const aoSalvar = (evento) => {
    evento.preventDefault();
    props.aoCadastrar({
      email,
      senha,
    });
    setEmail("");
    setSenha("");
  }; */

  const Login = (props) => {


    const [email, setEmail] = useState('')
    const [senha, setSenha] = useState('')


    const aoSalvar = (evento) => {
        evento.preventDefault()
        props.aoCadastrar({
            email,
            senha
        })
        setEmail('')
        setSenha('')

    }

  return (
    <>
      <div className="cadastro">
        <section className="formulario">
          <img className="arrowBack" src="/imgs/icons/Vector.png"/>
          <div>
            <img className="logo" src="/imgs/Group 39.png" />
          </div>
          <div className="cadastroBarProgress">
            <h1></h1>
          </div>
          <form onSubmit={aoSalvar}>
          <CampoTexto
              obrigatorio={true}
              label="Email"
              placeholder="seuemail@email.com"
              valor={email}
              aoAlterado={(valor) => setEmail(valor)}
          />
          <CampoTexto
            obrigatorio={true}
            label="Senha"
            placeholder="***********"
            valor={senha}
            aoAlterado={(valor) => setSenha(valor)}
          />
            <div className="divBotao">
              <Botao>Enviar</Botao>
            </div>
          </form>
        </section>

        <img
          className="sideImageCadastro"
          src="./imgs/estacionamento_static.png"
        />
      </div>
    </>
  );
};

export default Login;